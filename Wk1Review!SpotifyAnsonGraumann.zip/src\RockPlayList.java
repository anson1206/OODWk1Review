/***
 * Anson Graumann
 * 8/30/24
 * RockPlaylist Class
 * In this class, it's a subclass of the Playlist class so it contains the information in the Playlist class
 * In this class, it adds a new method call Instruments to display what instruments are expected to hear in the songs
 *
 */
public class RockPlayList extends Playlist{

    public void intstruments(){
        System.out.println("Drums");
        System.out.println("Electric Guitar");
    }


}
