/***
 * Anson Graumann
 * 8/30/24
 * User Class
 * In this class, we're creating a user with a name and a playlist
 * The user will be able to create a playlist, delete a playlist, add a song to a playlist,
 * and remove a song from a playlist
 */

import java.util.List;

public class User {
    public String name;
    public Playlist playlist;


    //creates a playlist based off of the type the user chooses
    public void createPlaylist(String name, String type){

        if(type.equals("Rock")){
            this.playlist = new RockPlayList();
        }else if(type.equals("Pop")){
            this.playlist = new PopPlaylist();
        }else if(type.equals("Jazz")){
            this.playlist = new JazzPlaylist();
        }
    }

   //deletes the playlist
    public void deletePlaylist(Playlist playlist){
        System.out.println("Removed " + playlist);
        this.playlist = null;
    }

    //adds a song to the playlist
    public void addSongToPlayList(Playlist playlist, Song song){
        System.out.println("Added " + song.getTitle() + " to " + playlist);
        playlist.addSong(song);
    }

    //removes a song from the playlist
    public void removeSongFromPlaylist(Playlist playlist, Song song){
        System.out.println("Removed " + song.getTitle() + " from " + playlist);
        playlist.removeSong(song);
    }

}
