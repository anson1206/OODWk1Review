/***
 * Anson Graumann
 * 8/30/24
 * PopPlaylist Class
 * In this class, it's a subclass of the Playlist class so it contains the information in the Playlist class
 * In this class, it adds a new method call Instruments to display what instruments are expected to hear in the songs
 *
 */
public class PopPlaylist extends Playlist{


    public void intstruments(){
        System.out.println("Piano");
        System.out.println("Guitar");
    }



}
