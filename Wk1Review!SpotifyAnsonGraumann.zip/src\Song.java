/***
 * Anson Graumann
 * 8/30/24
 * Song Class
 * In this class, we're creating a song with a title, artist, and duration
 * Inisde this class we have a constructor to initialize the song with title, artist, and duration and
 * a getter to return the title, artist, and duration
 */

public class Song {
    private String title, artist;
    private double duration;

   //constructor
    public Song(String title, String artist, double duration){
        this.title = title;
        this.artist = artist;
        this.duration = duration;
    }

    //getters
    public String getTitle() {
        return title;
    }

    public String getArtist() {
        return artist;
    }

    public double getDuration() {
        return duration;
    }
}
