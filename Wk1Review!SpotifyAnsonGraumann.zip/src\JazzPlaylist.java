/***
 * Anson Graumann
 * 8/30/24
 * JazzPlaylist Class
 * In this class, it's a subclass of the Playlist class so it contains the information in the Playlist class
 * In this class, it adds a new method call Instruments to display what instruments are expected to hear in the songs
 *
 */
public class JazzPlaylist extends Playlist{

    public void intstruments(){
        System.out.println("Violin");
        System.out.println("Flute");
    }
}
