/***
 * Anson Graumann
 * 8/30/24
 * Main Class
 * In this class, it acts like a testing class
 * This class is testing how the songs are added and how the playlists work
 * Resources used in the project:
 * Head First Java, 3rd Edition Chapter 6: Using the Java Library
 * Section "Some things you can do with ArrayList"
 *
 * Head First Java, 3rd Edition Chapter 8: Serious Polymorhism
 */

public class Main {

    public static void main(String[] args) {
        //Creating a user and a playlist
        User user = new User();
        user.createPlaylist("Pop", "Pop");
        //creating the songs that can be added to the playlist
        Song song1 = new Song("Bohemian Rhapsody", "Queen", 5.55);
        Song song2 = new Song("Don't Stop Me Now", "Queen", 3.55);
        Song song3 = new Song("We Will Rock You", "Queen", 4.55);

        //Shows what kind of instruments are expected to hear in the songs
        user.playlist.intstruments();
        //adds the songs to the playlist
        user.addSongToPlayList(user.playlist, song1);
        user.addSongToPlayList(user.playlist, song2);
        user.addSongToPlayList(user.playlist, song3);

        //Plays all the songs, removes a song, and plays all the songs again to show that the song was removed
        user.playlist.playAllSongs();
        user.removeSongFromPlaylist(user.playlist,song1);
        user.playlist.playAllSongs();

        // Shows that the playlist can be deleted and can add another one
        user.deletePlaylist(user.playlist);
        user.createPlaylist("Rock", "Rock");

        //SHows what kind of instruments are expected to hear in the songs and adds the songs to the new playlist
        user.playlist.intstruments();
        Song song4 = new Song("Smells Like teen spirit", "Nirvana", 5.55);
        Song song5 = new Song("Smells Like teen spirit", "Nirvana", 5.55);
        user.addSongToPlayList(user.playlist, song4);
        user.addSongToPlayList(user.playlist, song5);
        user.playlist.playAllSongs();



    }
}
