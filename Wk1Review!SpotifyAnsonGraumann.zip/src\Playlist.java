/***
 * Anson Graumann
 * 8/30/24
 * Playlist Class
 * In this class we're creating a playlist with a name and a list of songs
 * We're using an array to easily add and remove songs from the playlist
 * We're also able to play all the songs in the playlist
 *
 */

import java.util.*;
public class Playlist {
    public String name;
    public List<Song> songs = new ArrayList<>();

    //This method adds a song to the playlist
    public void addSong(Song song){
        songs.add(song);
    }

    //This method removes a song from the playlist
    public void removeSong(Song song){
        songs.remove(song);
    }

    //This method will print out all the songs in the playlist
    public void playAllSongs(){
        for(int i =0; i < songs.size(); i++){
            System.out.println("Current song: " + songs.get(i).getTitle() + " by " + songs.get(i).getArtist());
        }
    }

   //This class is used for poolymorphism for the other playlists so they can display what instruments are used in that
   //playlist
    public void intstruments(){
        System.out.println("This playlist has no instruments");
    }
}
