/***
 * Anson Graumann
 * 8/28/24
 * MenuItem class
 * In this class, it acts like a controller. It handels the menue items and gets/ sets
 * the information for each item,
 * This class also handels how the the information is displayed
 */
public class MenuItem {
    private String name;
    private double price;
    private String category;

    //constructor
    public MenuItem(String name, double price, String category){
        this.name = name;
        this.price = price;
        this.category = category;
    }
    //getters
    public String getName(){
        return name;
    }
    public double getPrice(){
        return price;
    }
     public String getCategory(){
        return category;
     }

     //setters
    public void setName(String name){
        this.name = name;
    }

    public void setPrice(double price){
        this.price = price;
    }

    public void setCategory(String category){
        this.category = category;
    }

    public void displayItemInfo(){
        System.out.println("Name: " + name);
        System.out.println("Price: " + price);
        System.out.println("Category: " + category);
    }
}
