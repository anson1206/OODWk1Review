/***
 * Anson Graumann
 * 8/28/24
 * Order class
 * In this class we're adding the items to the order and calculating the total by adding each item
 * price.
 * This class also displays the order details and total
 */
public class Order{

    private MenuItem item1;
    private MenuItem item2;
    private MenuItem item3;
    private double totalAmount;

    //adds the items

    public void addItem1(MenuItem item1){
        this.item1 = item1;
    }
    public void addItem2(MenuItem item2){
        this.item2 = item2;
    }
    public void addItem3(MenuItem item3){
        this.item3 = item3;
    }

    //calculates the total
    public void calculateTotal(){

        totalAmount += item1.getPrice();
        totalAmount += item2.getPrice();
        totalAmount += item3.getPrice();
    }
    //displays the order details and total amount
    // calls the display info method from the MenuItem class
    public void displayOrderDetails (){
        item1.displayItemInfo();
        item2.displayItemInfo();
        item3.displayItemInfo();
        System.out.println("Total Amount: $" + totalAmount);
    }

}
