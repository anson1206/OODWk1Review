/***
 * Anson Graumann
 * 8/28/24
 * Cafe class
 * In this class we're adding the menue items to the cafe menu and placing an order
 * The class also displays the menu with its respective information
 */

public class Cafe {
    private MenuItem menuItem1;
    private MenuItem menuItem2;
    private MenuItem menuItem3;

    private Order currentOrder;

    //adds items to the menu
    public void addMenuItem1(MenuItem item){
        this.menuItem1 = item;
    }

    public void addMenuItem2(MenuItem item){
        this.menuItem2 = item;
    }

    public void addMenuItem3(MenuItem item){
        this.menuItem3 = item;
    }

    //places the order and calculates the total
    public void placeOrder(Order order){
        this.currentOrder = order;
        //calls the calculate total method from the Order class
        currentOrder.calculateTotal();
    }

    //displays all the information
    //calls the display method from the MenueItem class
    public void displayMenue(){
        menuItem1.displayItemInfo();
        menuItem2.displayItemInfo();
        menuItem3.displayItemInfo();
    }
}
