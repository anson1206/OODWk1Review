/***
 * Anson Graumann
 * 8/28/24
 * Main class
 * In this class we created a menu for a cafe that we can add items too and calcilate the total
 * This class acts like a testing class to make sure everything is working correctly
 */

public class Main {
    public static void main(String[] args){
        //adds items to the menue with names, prices, and categories
        MenuItem coffee = new MenuItem("Coffee", 2.00, "beverage");
        MenuItem panini = new MenuItem("panini", 5.99, "panini");
        MenuItem tea = new MenuItem("Tea", 3.99, "beverage");

        //adds the items to the cafe menue and displays them
        Cafe cafe = new Cafe();
        cafe.addMenuItem1(coffee);
        cafe.addMenuItem2(panini);
        cafe.addMenuItem3(tea);
        System.out.println("Menu: ");
        cafe.displayMenue();

        //places the order and displays it
        Order order = new Order();
        order.addItem1(coffee);
        order.addItem2(panini);
        order.addItem3(tea);

        cafe.placeOrder(order);
        System.out.println("Order: ");
        order.displayOrderDetails();
    }
}
